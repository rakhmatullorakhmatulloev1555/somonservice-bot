from aiogram import Bot
from app.config import BOT_TOKEN

bot = Bot(token=BOT_TOKEN)
