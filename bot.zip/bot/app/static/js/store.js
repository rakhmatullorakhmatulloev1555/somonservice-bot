export const store={

 tickets:[],

 setTickets(data){

   this.tickets=data
   renderBoard()

 }

}
