MASTER_SPECIALTIES = {
    "master_cartridge": "Мастер по заправке картриджей",
    "master_printer_bw": "Мастер принтера (ч/б)",
    "master_printer_color": "Мастер по цветным принтерам",
    "master_pc": "Мастер ПК и ноутбуков (тех-мастер)",
    "master_programmer": "Мастер-программист",
    "master_washer": "Мастер по стиральным машинам",
    "master_conditioner": "Мастер по кондиционерам",
    "master_senior": "Старший мастер",
    "master_security": "Мастер по камерам, домофонам, СКУД",
    "master_automation": "Мастер по автоматизации и 1С + интеграция",
    "master_kholodilnik": "Мастер по холодилникам",
}
