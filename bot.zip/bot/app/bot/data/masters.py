MASTERS = [

    {
        "name": "Илхомиддин",
        "profession": "Инженер Автоматищации",
        "telegram_id": 6284411828
    },

    {
        "name": "Rain",
        "profession": "Технический мастерт",
        "telegram_id": 7042380459
    },

    {
        "name": "Нозим",
        "profession": "Мастер цветных принтеров",
        "telegram_id": 803524424
    },

    {
        "name": "Mr. PresidenT",
        "profession": "Мастер на выезд",
        "telegram_id": 905376510
    },

    {
        "name": "Баходур",
        "profession": "Мастер универсал",
        "telegram_id": 6504714572
    },

    {
        "name": "Навруз Асадуллоев",
        "profession": "Руководитель сервисного центра",
        "telegram_id": 6969369101
    },

    {
        "name": "Комрон",
        "profession": "Менеджер Продаж",
        "telegram_id": 125475085
    },

    {
        "name": "Сомон Сервис",
        "profession": "Маркази хизматрасонии Сомон",
        "telegram_id": 152157072
    },

    {
        "name": "Бахром",
        "profession": "Ведущий Инженер",
        "telegram_id": 955659013
    },

    {
        "name": "Фируз",
        "profession": "Мастер СКУД, Видеонаблюдения",
        "telegram_id": 1069259723
    },

    {
        "name": "Рахматулло",
        "profession": "Программист",
        "telegram_id": 8198019891
    }

]
